import javax.swing.*;

public class tempCodeRunnerFile {
    public static void main(String[] args) {
        Timer timer = new javax.swing.Timer(1000, e -> {
            System.out.println("Timer tick");
        });
        timer.start();

        // Keep program running for a few seconds
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}